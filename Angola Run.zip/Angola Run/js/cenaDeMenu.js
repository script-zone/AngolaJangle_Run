export default class CenaDeMenu extends Phaser.Scene {
  constructor() {
    super({
      key: "CenaDeMenu",
    });
  }

  preload() {}

  create() {}

  update() {}
}
